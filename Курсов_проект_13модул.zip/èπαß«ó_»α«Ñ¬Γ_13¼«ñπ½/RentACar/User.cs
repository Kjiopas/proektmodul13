﻿using System;

namespace RentACar
{
    public class User
    {
        public User(string userName, string password, string firstName, string lastName, string eGN, string gSM, string email, bool isAdmin)
        {
            UserName = userName;
            Password = password;
            FirstName = firstName;
            LastName = lastName;
            EGN = eGN;
            GSM = gSM;
            Email = email;
            IsAdmin = isAdmin;
        }

        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EGN { get; set; }
        public string GSM { get; set; }
        public string Email { get; set; }
        public bool IsAdmin { get; set; }
    }
}
