﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar
{
    public class Car
    {
        public Car(string brand, string model, int year, int seats, string description, decimal pricePerDay)
        {
            Brand = brand;
            Model = model;
            Year = year;
            Seats = seats;
            Description = description;
            PricePerDay = pricePerDay;
        }

        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int Seats { get; set; }
        public string Description { get; set; }
        public decimal PricePerDay { get; set; }
    }
}
